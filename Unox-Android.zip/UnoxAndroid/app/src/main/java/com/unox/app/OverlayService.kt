package com.unox.app

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.Gravity
import android.view.WindowManager
import android.webkit.JavascriptInterface
import android.webkit.WebView

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var web: WebView
    private lateinit var lp: WindowManager.LayoutParams

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(i: Intent?): IBinder? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate() {
        super.onCreate()
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("unox", "Unox", NotificationManager.IMPORTANCE_MIN))
        startForeground(1, Notification.Builder(this, "unox")
            .setContentTitle("Unox is running").setSmallIcon(android.R.drawable.ic_menu_info_details).build())

        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        lp = WindowManager.LayoutParams(
            dp(64), dp(64),
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(12); y = dp(220) }

        web = WebView(this).apply {
            setBackgroundColor(Color.TRANSPARENT)
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            addJavascriptInterface(Bridge(), "Android")
            loadUrl("file:///android_asset/index.html")
        }
        wm.addView(web, lp)
    }

    private fun clamp() {
        val m = resources.displayMetrics
        lp.x = lp.x.coerceIn(0, (m.widthPixels - lp.width).coerceAtLeast(0))
        lp.y = lp.y.coerceIn(0, (m.heightPixels - lp.height).coerceAtLeast(0))
    }

    inner class Bridge {
        @JavascriptInterface fun move(dx: Float, dy: Float) = web.post {
            lp.x += dx.toInt(); lp.y += dy.toInt(); clamp(); wm.updateViewLayout(web, lp)
        }
        @JavascriptInterface fun expand(on: Boolean) = web.post {
            val m = resources.displayMetrics
            lp.width = if (on) minOf(dp(340), m.widthPixels - dp(16)) else dp(64)
            lp.height = if (on) minOf(dp(560), m.heightPixels - dp(96)) else dp(64)
            clamp(); wm.updateViewLayout(web, lp)
        }
        @JavascriptInterface fun focus(on: Boolean) = web.post {
            lp.flags = if (on) lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
                       else lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
            wm.updateViewLayout(web, lp)
        }
        @JavascriptInterface fun close() { stopSelf() }
    }

    override fun onDestroy() {
        if (::web.isInitialized) { wm.removeView(web); web.destroy() }
        super.onDestroy()
    }
}
