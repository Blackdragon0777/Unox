package com.unox.app

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(Color.BLACK)
            setPadding((24 * d).toInt(), 0, (24 * d).toInt(), 0)
        }
        root.addView(TextView(this).apply {
            text = "UNOX"; textSize = 44f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD; letterSpacing = 0.15f; gravity = Gravity.CENTER
        })
        root.addView(TextView(this).apply {
            text = "Floating counter-build assistant.\nStart it, then open your game and tap the U bubble."
            setTextColor(Color.parseColor("#8c8c8c")); gravity = Gravity.CENTER
            setPadding(0, (12 * d).toInt(), 0, (28 * d).toInt())
        })
        root.addView(Button(this).apply {
            text = "Start floating assistant"; setOnClickListener { start() }
        })
        root.addView(Button(this).apply {
            text = "Stop"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) }
        })
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val i = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(i) else startService(i)
        moveTaskToBack(true)
    }
}
