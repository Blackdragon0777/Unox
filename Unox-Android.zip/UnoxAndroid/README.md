# Unox – Android project
1. Open this folder in Android Studio (Hedgehog or newer) and let Gradle sync.
2. Build > Build Bundle(s) / APK(s) > Build APK(s). Output: app/build/outputs/apk/.
3. Host the APK anywhere, then paste its link into `APK_URL` in the website file.
The floating UI lives in app/src/main/assets/index.html (the same file as the website).
Kotlin side: MainActivity (permission + start) and OverlayService (movable overlay window).
